package de.hseesslingen.helloesslingen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloEsslingenApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloEsslingenApplication.class, args);
	}
}
